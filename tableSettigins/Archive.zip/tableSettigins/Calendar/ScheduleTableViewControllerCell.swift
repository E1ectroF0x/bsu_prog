//
//  ScheduleTableViewControllerCell.swift
//  tableSettigins
//
//  Created by Alexey Meleshkevich on 16.12.2019.
//  Copyright © 2019 Li. All rights reserved.
//

import Foundation
import UIKit

class ScheduleTableViewControllerCell: UITableViewCell {
    
    @IBOutlet weak var timeCell: UILabel!
    @IBOutlet weak var typeCell: UILabel!
    @IBOutlet weak var lessonCell: UILabel!
    @IBOutlet weak var teacherCell: UILabel!
    @IBOutlet weak var locationCell: UILabel!
    
}
